import pyautogui as gui
import time
from PDFSender import *
from links import *
import os
from DatabaseConnector import DatabaseConnector

db = DatabaseConnector()
db.connect()
orders = db.fetch_orders()


def __wait_until_image_is_displayed(image_path, sec, order_no=None):
    for _ in range(sec):
        try:
            point = gui.locateOnScreen(image_path, confidence=0.85)
            if point:
                time.sleep(1)
                return point

        except gui.ImageNotFoundException:
            pass

        time.sleep(1.0)

    if order_no:
        log_error(order_no, image_path)
    return False

def __wait_until_alert_is_displayed(image_path, sec, order_no=None):
    for _ in range(sec):
        try:
            point = gui.locateOnScreen(image_path, confidence=0.85)
            if point:
                time.sleep(1)
                with open('errors.txt', 'a') as f:
                    f.write(f"Faktura: {order_no} - ALERT appeared\n")
                return point

        except gui.ImageNotFoundException:
            pass

        time.sleep(1.0)
    return False

def open_teta():
    gui.hotkey('winleft', 'd')
    time.sleep(2)
    point = __wait_until_image_is_displayed(frog_png, 10)
    if point:
        print(f"Found {frog_png} at {point}")
        gui.doubleClick(point, duration=0.5)

        if __wait_until_image_is_displayed(logowanie_png, 10):
            print(f"Found {logowanie_png} at {gui.locateOnScreen(logowanie_png, confidence=0.85)}")
            gui.press('enter')
            print("pressed enter")


def close_teta():
    gui.hotkey('altleft', 'f4')


def close_window():
    okno = __wait_until_image_is_displayed(okno_png, 20)
    gui.click(okno)
    gui.press(['up', 'enter'])


def log_error(symbol, image_path):
    with open('errors.txt', 'a') as f:
        f.write(f"Faktura: {symbol} - Nie znaleziono zdjecia:  {image_path}\n")


def check_image_displayed(image_path, sec, order_no=None):
    point = __wait_until_image_is_displayed(image_path, sec, order_no)
    if not point:
        print(f"Skipping invoice {order_no} as {image_path} not found")
        close_window()
        return False
    return point


def alert_appeared(order_no, image_path):
    print(f"Skipping invoice {order_no} as {image_path} ALERT appeared")
    close_window()
    return False


def process(order_no):
    try:
        time.sleep(6)
        gui.hotkey('altleft')
        gui.hotkey('altleft', '1')
        time.sleep(2)
        gui.hotkey('ctrl', 'f12')
        time.sleep(2)
        gui.press('enter')

        time.sleep(4)

        numer_odbiorcy = check_image_displayed(num_odb_png, 26, order_no)
        if not numer_odbiorcy:
            return False

        gui.click(numer_odbiorcy, duration=0.25)
        gui.write(' ' + ' ' + str(order_no).upper(), interval=0.25)
        gui.press("enter")
        time.sleep(2)
        gui.moveRel(-100, 30, duration=0.25)
        gui.click()

        sprzedaz_wysylkowa = check_image_displayed(sprzedaz_wysylkowa_png, 26, order_no)
        if not sprzedaz_wysylkowa:
            return False

        gui.click(sprzedaz_wysylkowa, duration=0.7)

        dane_wysylkowe_ZSB = check_image_displayed(dane_wysylkowe_ZSB_png, 26, order_no)
        if not dane_wysylkowe_ZSB:
            return False

        gui.click(dane_wysylkowe_ZSB, duration=0.25)

        alert = __wait_until_alert_is_displayed(alert_png, 8, order_no)
        if alert:
            gui.press('enter')
            time.sleep(2)
            alert_appeared(order_no, alert_png)
            return False

        dane_adresowe = check_image_displayed(dane_adresowe_png, 26, order_no)
        if not dane_adresowe:
            return False

        # time.sleep(3) - przywroc jak dane adresowe nie dzialaja i nie wyskakuje

        gui.press('enter')
        time.sleep(3)
        gui.press('f11')
        time.sleep(3)
        gui.press('enter')
        time.sleep(3)

        generuj_dok = check_image_displayed(generuj_dok_png, 26, order_no)
        if not generuj_dok:
            return False

        time.sleep(2)
        gui.click(generuj_dok, duration=0.25)

        generowanie_dok = check_image_displayed(generowanie_dok_png, 26, order_no)
        if not generowanie_dok:
            return False

        gui.press('enter')

        alert = __wait_until_alert_is_displayed(alert_png, 9, order_no)
        if alert:
            gui.press('enter')
            time.sleep(2)
            anuluj = check_image_displayed(anuluj_png, 10, order_no)
            gui.click(anuluj)
            time.sleep(3)
            alert_appeared(order_no, alert_png)
            return False

        faktury_sprzedazy = check_image_displayed(faktury_sprzedazy_png, 26, order_no)
        if not faktury_sprzedazy:
            return False

        fsw_sprzed_wys = check_image_displayed(sprzedaz_wysylkowa_png, 26, order_no)
        if not fsw_sprzed_wys:
            return False

        gui.click(fsw_sprzed_wys, duration=0.25)
        time.sleep(2)

        fsw_dane_wys = check_image_displayed(dane_wysylkowe_png, 26, order_no)
        if not fsw_dane_wys:
            return False


        gui.click(fsw_dane_wys, duration=0.25)

        dane_adresowe2 = check_image_displayed(dane_adresowe_png, 26, order_no)
        if not dane_adresowe2:
            return False

        # time.sleep(3) - przywroc jak dane adresowe nie dzialaja

        gui.press('enter')
        time.sleep(7)  # zatwierdzenie danych wysyłkowych na FSW
        gui.press('f11')  # zatwierdzenie FSW
        time.sleep(6)
        gui.press('enter')
        time.sleep(5)  # dokument zatwierdzony

        # # Pre Drukowanie szablon niestandardowy
        #
        # pre_drukowanie = check_image_displayed(pre_drukowanie_png, 20, order_no)
        # if not pre_drukowanie:
        #     return False
        #
        # gui.click(pre_drukowanie, duration=0.25)
        # faktura_walutowa = check_image_displayed(faktura_walutowa_png, 22, order_no)
        # if not faktura_walutowa:
        #     return False
        #
        # gui.press('enter')
        #
        # faktura_walutowa_wygenerowana = check_image_displayed(faktura_walutowa_wygenerowana_png, 22, order_no)
        # if not faktura_walutowa_wygenerowana:
        #     return False
        #
        # time.sleep(2)  # dokument zatwierdzony
        #
        # drukowanie = check_image_displayed(drukowanie_png, 20, order_no)
        # if not drukowanie:
        #     return False
        #
        # gui.click(drukowanie, duration=0.25)
        #
        # drukowanie_obraz = check_image_displayed(drukowanie_obraz_png, 20, order_no)
        # if not drukowanie_obraz:
        #     return False
        #
        # gui.press('enter')
        #
        # zapisywanie_wydruku = check_image_displayed(zapisywanie_wydruku_png, 20, order_no)
        # if not zapisywanie_wydruku:
        #     return False
        #
        # nazwa_pliku = check_image_displayed(nazwa_pliku_png, 20, order_no)
        # if not nazwa_pliku:
        #     return False
        #
        # numeric_part = ''.join(filter(str.isdigit, order_no))
        #
        # gui.write(numeric_part, interval=0.25)
        # time.sleep(6)
        # gui.hotkey('altleft', 'z')
        # time.sleep(4)


        for _ in range(2):
            close_window()
            time.sleep(2)
        return True

    except Exception as e:
        print(f"Error processing invoice {order_no}: {e}")
        return False


if __name__ == "__main__":
    if not orders:
        print("Brak faktur.")
    else:
        open_teta()
        start_job = time.time()
        for order in orders:
            start = time.time()
            print(f"start of looping item: {order}")
            if process(order):
                db.delete_order(order)
                # numeric_part_of_invoice = ''.join(filter(str.isdigit, order))
                # pdf_path = os.path.join(invoices_path, f"{numeric_part_of_invoice}.pdf")
                # send_invoice_via_api(numeric_part_of_invoice, pdf_path)
            else:
                print(f"Failed to process order: {order}")
            print(f"end of looping item: {order}")
            end = time.time()
            print(f'Order {order} finished in: ', time.strftime("%H:%M:%S", time.gmtime(end - start)) + '\n')

        end_job = time.time()
        print('Job finished in: ', time.strftime("%H:%M:%S", time.gmtime(end_job - start_job)))
        print('\n')
        db.close()
        close_teta()
